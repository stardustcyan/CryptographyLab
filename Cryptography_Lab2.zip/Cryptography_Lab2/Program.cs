﻿using System.Numerics;

namespace Cryptography_Lab2;

public class Program
{
    private const string fileName = "lab2-Plaintext.txt";

    private static string ReadPlainText()
    {
        StreamReader sr = new StreamReader(fileName);
        return sr.ReadLine() ?? "";
    }
    private static void PrintCryptionResult(BigInteger[] text)
    {
        Console.WriteLine("RSA加密结果为：");
        foreach (var i in text)
        {
            Console.WriteLine(i);
        }
    }
    public static void Main(string[] args)
    {
        var rsa = new Rsa();
        
        Console.WriteLine("正在读取明文...");
        var content = ReadPlainText();
        
        Console.WriteLine("读取的明文内容为：{0}", content);
        
        var ciphertext = rsa.Encryption(content);
        PrintCryptionResult(ciphertext);
        
        Console.WriteLine("解密结果为： " + rsa.Decryption(ciphertext));
    }
}